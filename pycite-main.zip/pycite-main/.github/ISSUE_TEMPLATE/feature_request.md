---

name: Feature Request
about: Suggest an improvement to our software
title: ''
labels: enhancement
assignees: ''

---

**Description**

Please describe the suggested feature in one sentence.

**Similar Features**

Please state if this enhances an existing feature. Write "N/A" if not applicable.

**Feature Details**

Please describe your suggested feature in enough detail.

**Proposed Implementation**

If you have an idea in mind, please list it here. Write "None" if otherwise.

---

Delete when you're ready to submit.

Thank you